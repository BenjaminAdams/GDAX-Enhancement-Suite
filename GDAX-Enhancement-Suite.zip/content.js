


setTimeout(function initGES () {

    setInterval(calculateOpenSells(),6000)


    function calculateOpenSells(){       
        var sellsPriceSum=0


            

            $('.ups-evaluecode').each(function (i, obj) {
			if(obj.className.includes('header')) return
			console.log(obj.className)            
            console.log(obj)
            
            //find OrderList_order-size
            var sizeDiv=$(obj).find('[class*=" OrderList_order-size"]')
            console.log(sizeDiv)
            sellsPriceSum+= 222
			
		}) 
    }




}, 150)
